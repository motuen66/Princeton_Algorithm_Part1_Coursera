//package algorithm_part_I.week1.hello;

import edu.princeton.cs.algs4.StdOut;

public class HelloWorld {
    public static void main(String[] args) {
        StdOut.println("Hello, World");
    }
}
