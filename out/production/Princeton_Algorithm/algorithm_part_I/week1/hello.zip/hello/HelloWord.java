package algorithm_part_I.week1.hello;

public class HelloWord {
}
